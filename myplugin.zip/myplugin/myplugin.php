<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://test
 * @since             1.0.0
 * @package           Myplugin
 *
 * @wordpress-plugin
 * Plugin Name:       My Plugin
 * Plugin URI:        https://test
 * Description:       Реализовать плагин для WP, который добавляет атрибуты для внешних ссылок в контенте при выводе the_content():
 * Version:           1.0.0
 * Author:            Abramchuk
 * Author URI:        https://test
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       myplugin
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}


define( 'MYPLUGIN_VERSION', '1.0.0' );
class Myplugin
{

	public function register(){
       
		add_filter( 'the_content', 'make_clickable' );
		function testing ($content) {
			$content = preg_replace_callback(
			'/<a[^>]*href=["|\']([^"|\']*)["|\'][^>]*>([^<]*)<\/a>/i',
			function($m) {
				$hasClass = (bool) preg_match('/class="[^"]*[^"]*"/', $m[0]);
		 
				if (strpos($m[1], home_url()) === false && $hasClass === false)
					return '<a href="'.$m[1].'" rel="nofollow" target="_blank">'.$m[2].'</a>';
				else
					return $m[0];
				},
		 
				$content);
				return $content;
			}
		add_filter('the_content', 'testing');
		
		
    }
	
	static function activation(){
        
        //update rewrite rules
        flush_rewrite_rules();
    }

    static function deactivation(){

        //update rewrite rules
        flush_rewrite_rules();
    }
}

if(class_exists('Myplugin')){
    $myplugin = new Myplugin();
    $myplugin->register();
}

register_activation_hook( __FILE__, array( $myplugin, 'activation' ) );
register_deactivation_hook( __FILE__, array( $myplugin, 'deactivation' ) );

